// Danh sách tài khoản mẫu (có thể thay đổi)
const users = [
    { username: "nguyensonhaihoang", password: "123456789" },
];

// Hàm hiển thị popup lỗi
function showPopup(message) {
    let popup = document.getElementById("errorPopup");
    let popupMessage = document.getElementById("popupMessage");
    popupMessage.innerText = message;
    popup.style.display = "block";
}

// Hàm đóng popup
function closePopup() {
    document.getElementById("errorPopup").style.display = "none";
}

// Hàm hiển thị/ẩn mật khẩu
function togglePassword() {
    let passwordInput = document.getElementById("password");
    let toggleIcon = document.getElementById("togglePassword");

    if (passwordInput.type === "password") {
        passwordInput.type = "text";
        toggleIcon.innerText = "🙈"; // Đổi icon
    } else {
        passwordInput.type = "password";
        toggleIcon.innerText = "👁️"; // Đổi icon
    }
}

// Xử lý sự kiện đăng nhập
document.getElementById("loginForm").addEventListener("submit", function(event) {
    event.preventDefault(); // Ngăn trang reload

    let username = document.getElementById("username").value.trim();
    let password = document.getElementById("password").value.trim();

    // Kiểm tra ô nhập có trống không
    if (username === "" || password === "") {
        showPopup("Vui lòng nhập đầy đủ thông tin!");
        return;
    }

    // Kiểm tra tài khoản
    let validUser = users.find(user => user.username === username && user.password === password);

    if (validUser) {
        alert("Đăng nhập thành công!");
        window.location.href = "https://www.canva.com/design/DAGfI_LGQGg/f5OypYzoJWYVyXikHcSdYw/edit"; // Chỉnh sửa đường dẫn nếu cần
    } else {
        showPopup("Tên đăng nhập hoặc mật khẩu không đúng!");
    }
});
